#include "interactive_tcp_server.h"
#include <csignal>
#include <iostream>

int main(int argc, char* argv[]) {
    if (argc != 2) {
        std::cout << "用法: " << argv[0] << " <端口>" << std::endl;
        return 1;
    }

    int port = std::atoi(argv[1]);
    
    signal(SIGINT, [](int) {
        std::cout << "\n关闭服务器..." << std::endl;
        exit(0);
    });

    try {
        InteractiveTCPServer server(port);
        server.start();
    } catch (const std::exception& e) {
        std::cerr << "服务器错误: " << e.what() << std::endl;
        return 1;
    }

    return 0;
}