#include <cstddef>
#ifndef CONSTANTS_H
#define CONSTANTS_H

const int DISCOVERY_PORT = 8888;
const size_t BUFFER_SIZE = 64 * 1024;
const int MAX_THREADS = 16;

#endif