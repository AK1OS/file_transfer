#include "transfer_handlers.h"
#include "session_manager.h"
#include "network_utils.h"
#include "../common/constants.h"
#include <iostream>
#include <fstream>
#include <vector>
#include <thread>
#include <chrono>
#include <iomanip>
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>
#include <sys/socket.h>
#include <cstring>

void ServerTransferHandlers::handleResumeQuery(int clientSocket) {
    try {
        int nameSize;
        if (recv(clientSocket, &nameSize, sizeof(int), MSG_WAITALL) != sizeof(int)) {
            close(clientSocket);
            return;
        }

        if (nameSize <= 0 || nameSize > 4096) {
            close(clientSocket);
            return;
        }

        std::vector<char> nameBuf(nameSize + 1);
        if (recv(clientSocket, nameBuf.data(), nameSize, MSG_WAITALL) != nameSize) {
            close(clientSocket);
            return;
        }
        nameBuf[nameSize] = '\0';
        std::string fileName = std::string(nameBuf.data());

        bool exists = false;
        long long transferred = 0;

        {
            std::lock_guard<std::mutex> lock(resumeMutex);
            auto it = resumePoints.find(fileName);
            if (it != resumePoints.end()) {
                exists = true;
                transferred = it->second;
            }
        }

        struct stat fileStat;
        if (stat(fileName.c_str(), &fileStat) == 0) {
            if (exists && transferred == fileStat.st_size) {
                exists = true;
            } else {
                std::lock_guard<std::mutex> lock(resumeMutex);
                resumePoints[fileName] = fileStat.st_size;
                transferred = fileStat.st_size;
                exists = true;
            }
        } else {
            std::lock_guard<std::mutex> lock(resumeMutex);
            resumePoints.erase(fileName);
            exists = false;
            transferred = 0;
        }

        send(clientSocket, &exists, sizeof(bool), 0);
        if (exists) {
            send(clientSocket, &transferred, sizeof(long long), 0);
        }

        std::cout << " 断点查询: " << fileName << " 存在: " << exists 
                  << " 已传输: " << transferred << std::endl;

    } catch (const std::exception& e) {
        std::cerr << "断点查询错误: " << e.what() << std::endl;
    }
    
    close(clientSocket);
}

void ServerTransferHandlers::handleResumeReset(int clientSocket) {
    try {
        int nameSize;
        if (recv(clientSocket, &nameSize, sizeof(int), MSG_WAITALL) != sizeof(int)) {
            close(clientSocket);
            return;
        }

        if (nameSize <= 0 || nameSize > 4096) {
            close(clientSocket);
            return;
        }

        std::vector<char> nameBuf(nameSize + 1);
        if (recv(clientSocket, nameBuf.data(), nameSize, MSG_WAITALL) != nameSize) {
            close(clientSocket);
            return;
        }
        nameBuf[nameSize] = '\0';
        std::string fileName = std::string(nameBuf.data());

        {
            std::lock_guard<std::mutex> lock(resumeMutex);
            resumePoints.erase(fileName);
        }

        std::remove(fileName.c_str());
        
        std::cout << " 重置传输: " << fileName << std::endl;

    } catch (const std::exception& e) {
        std::cerr << "重置传输错误: " << e.what() << std::endl;
    }
    
    close(clientSocket);
}

void ServerTransferHandlers::handleSequentialTransfer(int clientSocket) {
    try {
        long long startPos;
        if (recv(clientSocket, &startPos, sizeof(long long), MSG_WAITALL) != sizeof(long long)) {
            throw std::runtime_error("接收起始位置失败");
        }

        FileAttributes attrs;
        if (recv(clientSocket, &attrs, sizeof(FileAttributes), MSG_WAITALL) != sizeof(FileAttributes)) {
            throw std::runtime_error("接收文件属性失败");
        }

        int nameSize;
        if (recv(clientSocket, &nameSize, sizeof(int), MSG_WAITALL) != sizeof(int)) {
            throw std::runtime_error("接收文件名长度失败");
        }

        if (nameSize <= 0 || nameSize > 4096) {
            throw std::runtime_error("无效的文件名长度");
        }

        std::vector<char> nameBuf(nameSize + 1);
        if (recv(clientSocket, nameBuf.data(), nameSize, MSG_WAITALL) != nameSize) {
            throw std::runtime_error("接收文件名失败");
        }
        nameBuf[nameSize] = '\0';
        std::string fileName = std::string(nameBuf.data());

        long long fileSize;
        if (recv(clientSocket, &fileSize, sizeof(long long), MSG_WAITALL) != sizeof(long long)) {
            throw std::runtime_error("接收文件大小失败");
        }

        std::cout << " 接收文件: " << fileName << " (" << formatFileSize(fileSize) 
                  << "), 起始位置: " << startPos << std::endl;

        std::ios_base::openmode mode = std::ios::binary;
        if (startPos > 0) {
            mode |= std::ios::app;
        } else {
            mode |= std::ios::trunc;
        }

        std::ofstream file(fileName, mode);
        if (!file.is_open()) {
            throw std::runtime_error("创建文件失败");
        }

        if (startPos > 0) {
            file.seekp(0, std::ios::end);
            long long currentSize = file.tellp();
            if (currentSize != startPos) {
                std::cout << "  文件大小不匹配，调整位置: " << currentSize << " -> " << startPos << std::endl;
                file.seekp(startPos);
            }
        }

        std::vector<char> buffer(BUFFER_SIZE);
        long long received = startPos;
        auto startTime = std::chrono::steady_clock::now();
        
        while (received < fileSize) {
            long long remaining = fileSize - received;
            size_t toReceive = std::min(remaining, static_cast<long long>(buffer.size()));
            
            int bytesRead = recv(clientSocket, buffer.data(), toReceive, 0);
            if (bytesRead <= 0) break;
            
            file.write(buffer.data(), bytesRead);
            received += bytesRead;
            
            if (received % (1024 * 1024) == 0) {
                std::lock_guard<std::mutex> lock(resumeMutex);
                resumePoints[fileName] = received;
            }
            
            if (received % (1024 * 1024) == 0) {
                double progress = (double)received / fileSize * 100;
                auto currentTime = std::chrono::steady_clock::now();
                auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(currentTime - startTime).count();
                double speed = (duration > 0) ? (double)(received - startPos) / duration / 1024 : 0;
                
                std::cout << "进度: " << std::fixed << std::setprecision(1) << progress 
                          << "%, 速度: " << std::setprecision(2) << speed << " KB/s\r" << std::flush;
            }
        }

        file.close();

        {
            std::lock_guard<std::mutex> lock(resumeMutex);
            if (received == fileSize) {
                resumePoints[fileName] = fileSize;
                std::cout << "\n 顺序传输完成" << std::endl;
            } else {
                resumePoints[fileName] = received;
                std::cout << "\n  传输中断，保存断点: " << received << std::endl;
            }
        }

        ServerNetworkUtils::setFileAttributes(fileName, attrs);

        std::string response = "传输完成，接收: " + std::to_string(received) + " 字节";
        send(clientSocket, response.c_str(), response.size(), 0);

    } catch (const std::exception& e) {
        std::cerr << "顺序传输错误: " << e.what() << std::endl;
    }
    
    close(clientSocket);
}

void ServerTransferHandlers::handleMultithreadControl(int clientSocket) {
    try {
        int numThreads;
        if (recv(clientSocket, &numThreads, sizeof(int), MSG_WAITALL) != sizeof(int)) {
            throw std::runtime_error("接收线程数失败");
        }

        if (numThreads > MAX_THREADS) {
            numThreads = MAX_THREADS;
            std::cout << "  线程数限制为" << MAX_THREADS << std::endl;
        }

        FileAttributes attrs;
        if (recv(clientSocket, &attrs, sizeof(FileAttributes), MSG_WAITALL) != sizeof(FileAttributes)) {
            throw std::runtime_error("接收文件属性失败");
        }

        int nameSize;
        if (recv(clientSocket, &nameSize, sizeof(int), MSG_WAITALL) != sizeof(int)) {
            throw std::runtime_error("接收文件名长度失败");
        }

        std::vector<char> nameBuf(nameSize + 1);
        if (recv(clientSocket, nameBuf.data(), nameSize, MSG_WAITALL) != nameSize) {
            throw std::runtime_error("接收文件名失败");
        }
        nameBuf[nameSize] = '\0';
        std::string fileName = std::string(nameBuf.data());

        long long fileSize;
        if (recv(clientSocket, &fileSize, sizeof(long long), MSG_WAITALL) != sizeof(long long)) {
            throw std::runtime_error("接收文件大小失败");
        }

        std::cout << " 接收文件: " << fileName << " (" << formatFileSize(fileSize) << ")" << std::endl;

        int sessionId = SessionManager::getInstance().createSession();
        auto session = SessionManager::getInstance().getSession(sessionId);
        session->fileName = fileName;
        session->fileSize = fileSize;
        session->totalChunks = numThreads;
        session->attrs = attrs;
        session->chunks.resize(numThreads);

        std::ofstream preFile(fileName, std::ios::binary);
        if (!preFile.is_open()) {
            throw std::runtime_error("创建文件失败: " + fileName);
        }
        preFile.close();

        session->fileStream = std::make_unique<std::fstream>(
            fileName, std::ios::binary | std::ios::in | std::ios::out
        );
        if (!session->fileStream->is_open()) {
            throw std::runtime_error("打开文件流失败: " + fileName);
        }

        std::cout << " 创建会话 " << sessionId << " (" << numThreads << " 个块)" << std::endl;

        send(clientSocket, &sessionId, sizeof(int), 0);
        close(clientSocket);

        std::thread([this, sessionId]() {
            SessionManager::getInstance().monitorSession(sessionId);
        }).detach();

    } catch (const std::exception& e) {
        std::cerr << "多线程控制错误: " << e.what() << std::endl;
        close(clientSocket);
    }
}

void ServerTransferHandlers::handleChunkTransfer(int clientSocket) {
    try {
        int header[4];
        if (recv(clientSocket, header, sizeof(header), MSG_WAITALL) != sizeof(header)) {
            throw std::runtime_error("接收块头失败");
        }

        int sessionId = header[0];
        int chunkIndex = header[1];
        long startPos = header[2];
        long long chunkSize = header[3];

        // 输出调试信息
        std::cout << "=== 接收块头信息 ===" << std::endl;
        std::cout << "Session ID: " << sessionId << std::endl;
        std::cout << "Chunk Index: " << chunkIndex << std::endl;
        std::cout << "Start Position: " << startPos << std::endl;
        std::cout << "Chunk Size: " << chunkSize << std::endl;
        std::cout << "====================" << std::endl;

        if (chunkSize <= 0 || chunkSize > 1024LL * 1024 * 1024) {
            throw std::runtime_error("无效的块大小: " + std::to_string(chunkSize));
        }

        auto session = SessionManager::getInstance().getSession(sessionId);
        if (!session || chunkIndex >= session->totalChunks || chunkIndex < 0) {
            std::cerr << "无效的块索引 " << chunkIndex << " 用于会话 " << sessionId << std::endl;
            close(clientSocket);
            return;
        }

        std::cout << " 接收块 " << chunkIndex << " (" << formatFileSize(chunkSize) << ")" << std::endl;

        {
            std::lock_guard<std::mutex> lock(session->fileMutex);
            
            session->fileStream->seekp(startPos);
            if (!session->fileStream->good()) {
                throw std::runtime_error("文件定位失败");
            }

            std::vector<char> buffer(BUFFER_SIZE);
            long long received = 0;
            
            while (received < chunkSize) {
                long long remaining = chunkSize - received;
                size_t toReceive = std::min(remaining, static_cast<long long>(buffer.size()));
                
                int bytesRead = recv(clientSocket, buffer.data(), toReceive, 0);
                if (bytesRead <= 0) {
                    throw std::runtime_error("接收块数据失败");
                }
                
                session->fileStream->write(buffer.data(), bytesRead);
                if (!session->fileStream->good()) {
                    throw std::runtime_error("文件写入失败");
                }
                
                received += bytesRead;
            }

            session->fileStream->flush();
        }

        {
            std::lock_guard<std::mutex> lock(session->fileMutex);
            session->chunks[chunkIndex].received = true;
            session->chunks[chunkIndex].writtenToFile = true;
            session->receivedChunks++;
            session->writtenChunks++;
        }
        
        std::cout << " 块 " << chunkIndex << " 接收完成" << std::endl;

        char ack = 'A';
        send(clientSocket, &ack, 1, 0);
        close(clientSocket);

    } catch (const std::exception& e) {
        std::cerr << "块传输错误: " << e.what() << std::endl;
        close(clientSocket);
    }
}

void ServerTransferHandlers::handleDirectoryTransfer(int clientSocket) {
    try {
        std::cout << " 开始接收文件夹..." << std::endl;
        
        int basePathLen;
        if (recv(clientSocket, &basePathLen, sizeof(int), MSG_WAITALL) != sizeof(int)) {
            throw std::runtime_error("接收基础路径长度失败");
        }
        
        std::vector<char> basePathBuf(basePathLen + 1);
        if (recv(clientSocket, basePathBuf.data(), basePathLen, MSG_WAITALL) != basePathLen) {
            throw std::runtime_error("接收基础路径失败");
        }
        basePathBuf[basePathLen] = '\0';
        std::string basePath = std::string(basePathBuf.data());
        
        if (mkdir(basePath.c_str(), 0755) != 0 && errno != EEXIST) {
            throw std::runtime_error("创建基础目录失败: " + std::string(strerror(errno)));
        }
        
        std::cout << " 创建基础目录: " << basePath << std::endl;
        
        int fileCount;
        if (recv(clientSocket, &fileCount, sizeof(int), MSG_WAITALL) != sizeof(int)) {
            throw std::runtime_error("接收文件数量失败");
        }
        
        std::cout << " 总共需要接收 " << fileCount << " 个文件/目录" << std::endl;
        
        int successCount = 0;
        int failCount = 0;
        
        for (int i = 0; i < fileCount; i++) {
            char itemType;
            if (recv(clientSocket, &itemType, 1, MSG_WAITALL) != 1) {
                throw std::runtime_error("接收项目类型失败");
            }
            
            if (itemType == 'F') {
                if (handleDirectoryFile(clientSocket, basePath)) {
                    successCount++;
                } else {
                    failCount++;
                }
            } else if (itemType == 'D') {
                if (handleDirectoryItem(clientSocket, basePath)) {
                    successCount++;
                } else {
                    failCount++;
                }
            }
            
            std::cout << " 进度: " << (i+1) << "/" << fileCount 
                      << " (成功: " << successCount << ", 失败: " << failCount << ")\r" << std::flush;
        }
        
        std::cout << "\n 文件夹传输完成! 成功: " << successCount << ", 失败: " << failCount << std::endl;
        
        std::string response = "文件夹传输完成，成功: " + std::to_string(successCount) + 
                             ", 失败: " + std::to_string(failCount);
        send(clientSocket, response.c_str(), response.size(), 0);
        
    } catch (const std::exception& e) {
        std::cerr << "文件夹传输错误: " << e.what() << std::endl;
    }
    
    close(clientSocket);
}

bool ServerTransferHandlers::handleDirectoryItem(int clientSocket, const std::string& basePath) {
    try {
        int pathLen;
        if (recv(clientSocket, &pathLen, sizeof(int), MSG_WAITALL) != sizeof(int)) {
            return false;
        }
        
        if (pathLen <= 0 || pathLen > 4096) return false;
        
        std::vector<char> pathBuf(pathLen + 1);
        if (recv(clientSocket, pathBuf.data(), pathLen, MSG_WAITALL) != pathLen) {
            return false;
        }
        pathBuf[pathLen] = '\0';
        std::string relPath = pathBuf.data();
        
        std::string fullPath = basePath + "/" + relPath;
        
        if (mkdir(fullPath.c_str(), 0755) != 0 && errno != EEXIST) {
            return false;
        }
        
        FileAttributes attrs;
        if (recv(clientSocket, &attrs, sizeof(FileAttributes), MSG_WAITALL) == sizeof(FileAttributes)) {
            ServerNetworkUtils::setFileAttributes(fullPath, attrs);
        }
        
        return true;
    } catch (...) {
        return false;
    }
}

bool ServerTransferHandlers::handleDirectoryFile(int clientSocket, const std::string& basePath) {
    try {
        int pathLen;
        if (recv(clientSocket, &pathLen, sizeof(int), MSG_WAITALL) != sizeof(int)) {
            return false;
        }
        
        if (pathLen <= 0 || pathLen > 4096) return false;
        
        std::vector<char> pathBuf(pathLen + 1);
        if (recv(clientSocket, pathBuf.data(), pathLen, MSG_WAITALL) != pathLen) {
            return false;
        }
        pathBuf[pathLen] = '\0';
        std::string relPath = pathBuf.data();
        
        std::string fullPath = basePath + "/" + relPath;
        
        std::string parentDir = fullPath.substr(0, fullPath.find_last_of('/'));
        if (!parentDir.empty()) {
            system(("mkdir -p \"" + parentDir + "\"").c_str());
        }
        
        FileAttributes attrs;
        if (recv(clientSocket, &attrs, sizeof(FileAttributes), MSG_WAITALL) != sizeof(FileAttributes)) {
            return false;
        }
        
        long long fileSize;
        if (recv(clientSocket, &fileSize, sizeof(long long), MSG_WAITALL) != sizeof(long long)) {
            return false;
        }
        
        std::ofstream file(fullPath, std::ios::binary);
        if (!file.is_open()) {
            return false;
        }
        
        std::vector<char> buffer(BUFFER_SIZE);
        long long received = 0;
        
        while (received < fileSize) {
            long long remaining = fileSize - received;
            size_t toReceive = std::min(remaining, static_cast<long long>(buffer.size()));
            
            int bytesRead = recv(clientSocket, buffer.data(), toReceive, 0);
            if (bytesRead <= 0) break;
            
            file.write(buffer.data(), bytesRead);
            received += bytesRead;
        }
        
        file.close();
        
        if (received == fileSize) {
            ServerNetworkUtils::setFileAttributes(fullPath, attrs);
            return true;
        }
        
        return false;
    } catch (...) {
        return false;
    }
}

std::string ServerTransferHandlers::formatFileSize(long long bytes) {
    const char* sizes[] = {"B", "KB", "MB", "GB"};
    int order = 0;
    double size = bytes;
    while (size >= 1024 && order < 3) {
        order++;
        size /= 1024;
    }
    
    std::string result = std::to_string(size);
    size_t dotPos = result.find('.');
    if (dotPos != std::string::npos && dotPos + 3 < result.length()) {
        result = result.substr(0, dotPos + 3);
    }
    return result + " " + sizes[order];
}