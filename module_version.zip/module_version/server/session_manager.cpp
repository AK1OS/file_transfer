#include "session_manager.h"
#include "network_utils.h"
#include "../common/constants.h"
#include <iostream>
#include <fstream>
#include <chrono>
#include <thread>
#include <sys/stat.h>

std::shared_ptr<FileSession> SessionManager::getSession(int sessionId) {
    std::lock_guard<std::mutex> lock(sessionsMutex);
    auto it = sessions.find(sessionId);
    if (it != sessions.end()) {
        return it->second;
    }
    
    // 添加调试信息
    std::cout << " 找不到会话: " << sessionId << ", 当前会话数量: " << sessions.size() << std::endl;
    for (const auto& pair : sessions) {
        std::cout << "  现有会话ID: " << pair.first << std::endl;
    }
    
    return nullptr;
}

int SessionManager::createSession() {
    std::lock_guard<std::mutex> lock(sessionsMutex);
    int sessionId = nextSessionId++;
    auto session = std::make_shared<FileSession>(sessionId);
    sessions[sessionId] = session;
    
    std::cout << " 创建新会话: " << sessionId << std::endl;
    return sessionId;
}

void SessionManager::removeSession(int sessionId) {
    std::lock_guard<std::mutex> lock(sessionsMutex);
    auto it = sessions.find(sessionId);
    if (it != sessions.end()) {
        sessions.erase(it);
        std::cout << " 移除会话: " << sessionId << std::endl;
    }
}

void SessionManager::monitorSession(int sessionId) {
    std::shared_ptr<FileSession> session = getSession(sessionId);
    if (!session) {
        std::cerr << " 监控失败: 找不到会话 " << sessionId << std::endl;
        return;
    }

    std::cout << " 开始监控会话 " << sessionId << std::endl;

    auto startTime = std::chrono::steady_clock::now();
    auto lastProgressTime = startTime;
    int lastReceived = 0;
    
    while (!session->completed) {
        int received = session->receivedChunks;
        int written = session->writtenChunks;
        
        if (received == session->totalChunks && written == session->totalChunks) {
            completeSession(session);
            break;
        }
        
        auto currentTime = std::chrono::steady_clock::now();
        auto duration = std::chrono::duration_cast<std::chrono::seconds>(currentTime - startTime).count();
        
        auto progressDuration = std::chrono::duration_cast<std::chrono::milliseconds>(currentTime - lastProgressTime).count();
        if (progressDuration > 1000 || received != lastReceived) {
            std::cout << "进度: " << received << "/" << session->totalChunks 
                      << " 块 (已写入: " << written << ")" << std::endl;
            lastProgressTime = currentTime;
            lastReceived = received;
        }
        
        if (duration > 300) {
            std::cerr << " 会话 " << sessionId << " 超时" << std::endl;
            break;
        }
        
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }

    if (session->fileStream) {
        session->fileStream->close();
    }

    removeSession(sessionId);
    
    std::cout << "  清理会话 " << sessionId << " 资源" << std::endl;
}

void SessionManager::completeSession(std::shared_ptr<FileSession> session) {
    std::cout << "\n 完成会话: " << session->fileName << std::endl;
    
    try {
        if (session->fileStream) {
            session->fileStream->close();
        }

        struct stat fileStat;
        if (stat(session->fileName.c_str(), &fileStat) == 0) {
            if (static_cast<long long>(fileStat.st_size) != session->fileSize) {
                std::cerr << "  文件大小不匹配: 期望 " << session->fileSize 
                          << ", 实际 " << fileStat.st_size << std::endl;
            }
        }

        ServerNetworkUtils::setFileAttributes(session->fileName, session->attrs);
        
        std::cout << " 文件传输完成: " << session->fileName << std::endl;
        std::cout << " 文件大小: " << formatFileSize(session->fileSize) << std::endl;
        
    } catch (const std::exception& e) {
        std::cerr << "完成会话错误: " << e.what() << std::endl;
    }
    
    session->completed = true;
}

std::string SessionManager::formatFileSize(long long bytes) {
    const char* sizes[] = {"B", "KB", "MB", "GB"};
    int order = 0;
    double size = bytes;
    while (size >= 1024 && order < 3) {
        order++;
        size /= 1024;
    }
    
    std::string result = std::to_string(size);
    size_t dotPos = result.find('.');
    if (dotPos != std::string::npos) {
        if (dotPos + 3 < result.length()) {
            result = result.substr(0, dotPos + 3);
        }
    }
    return result + " " + sizes[order];
}