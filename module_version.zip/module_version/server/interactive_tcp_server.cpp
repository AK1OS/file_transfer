#include "interactive_tcp_server.h"
#include "session_manager.h"
#include "transfer_handlers.h"
#include "network_utils.h"
#include "../common/constants.h"
#include <iostream>
#include <thread>
#include <csignal>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <cstring>

InteractiveTCPServer::InteractiveTCPServer(int port) {
    serverSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (serverSocket < 0) {
        throw std::runtime_error("Socket creation failed");
    }

    int opt = 1;
    if (setsockopt(serverSocket, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) < 0) {
        close(serverSocket);
        throw std::runtime_error("Setsockopt failed");
    }

    int bufSize = 1024 * 1024;
    setsockopt(serverSocket, SOL_SOCKET, SO_RCVBUF, &bufSize, sizeof(bufSize));

    struct sockaddr_in serverAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = INADDR_ANY;
    serverAddr.sin_port = htons(port);

    if (bind(serverSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) < 0) {
        close(serverSocket);
        throw std::runtime_error("Bind failed");
    }

    if (listen(serverSocket, 10) < 0) {
        close(serverSocket);
        throw std::runtime_error("Listen failed");
    }

    discoverySocket = socket(AF_INET, SOCK_DGRAM, 0);
    if (discoverySocket < 0) {
        close(serverSocket);
        throw std::runtime_error("Discovery socket creation failed");
    }

    struct sockaddr_in discoveryAddr;
    discoveryAddr.sin_family = AF_INET;
    discoveryAddr.sin_addr.s_addr = INADDR_ANY;
    discoveryAddr.sin_port = htons(DISCOVERY_PORT);

    if (bind(discoverySocket, (struct sockaddr*)&discoveryAddr, sizeof(discoveryAddr)) < 0) {
        close(serverSocket);
        close(discoverySocket);
        throw std::runtime_error("Discovery bind failed");
    }

    int broadcastEnable = 1;
    if (setsockopt(discoverySocket, SOL_SOCKET, SO_BROADCAST, 
                   &broadcastEnable, sizeof(broadcastEnable)) < 0) {
        std::cerr << "  设置发现套接字广播选项失败" << std::endl;
    }

    std::cout << " 服务器启动成功，主端口: " << port << std::endl;
    std::cout << " 服务发现端口: " << DISCOVERY_PORT << std::endl;
}

InteractiveTCPServer::~InteractiveTCPServer() {
    running = false;
    discoveryRunning = false;
    
    if (serverSocket >= 0) {
        close(serverSocket);
    }
    if (discoverySocket >= 0) {
        close(discoverySocket);
    }
}

void InteractiveTCPServer::start() {
    running = true;

    std::thread discoveryThread(&InteractiveTCPServer::startDiscoveryService, this);
    discoveryThread.detach();
    
    std::cout << " 等待客户端连接..." << std::endl;

    while (running) {
        struct sockaddr_in clientAddr;
        socklen_t clientAddrLen = sizeof(clientAddr);
        int clientSocket = accept(serverSocket, (struct sockaddr*)&clientAddr, &clientAddrLen);
        
        if (clientSocket < 0) {
            if (running) {
                std::cerr << "接受连接失败" << std::endl;
            }
            continue;
        }

        char clientIP[INET_ADDRSTRLEN];
        inet_ntop(AF_INET, &clientAddr.sin_addr, clientIP, sizeof(clientIP));
        std::cout << " 新客户端连接: " << clientIP << ":" << ntohs(clientAddr.sin_port) << std::endl;

        std::thread([this, clientSocket]() {
            handleClient(clientSocket);
        }).detach();
    }
}

void InteractiveTCPServer::startDiscoveryService() {
    discoveryRunning = true;
    std::cout << " 服务发现服务已启动..." << std::endl;
    
    while (discoveryRunning) {
        char buffer[256];
        struct sockaddr_in clientAddr;
        socklen_t clientLen = sizeof(clientAddr);
        
        struct timeval timeout;
        timeout.tv_sec = 1;
        timeout.tv_usec = 0;
        setsockopt(discoverySocket, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));
        
        int bytesReceived = recvfrom(discoverySocket, buffer, sizeof(buffer)-1, 0,
                                   (struct sockaddr*)&clientAddr, &clientLen);
        
        if (bytesReceived > 0) {
            buffer[bytesReceived] = '\0';
            
            if (strcmp(buffer, "FILE_SERVER_DISCOVER") == 0) {
                char clientIP[INET_ADDRSTRLEN];
                inet_ntop(AF_INET, &clientAddr.sin_addr, clientIP, sizeof(clientIP));
                
                std::cout << " 收到发现请求来自: " << clientIP << std::endl;
                
                struct sockaddr_in serverAddr;
                socklen_t serverLen = sizeof(serverAddr);
                if (getsockname(serverSocket, (struct sockaddr*)&serverAddr, &serverLen) == 0) {
                    int mainPort = ntohs(serverAddr.sin_port);
                    
                    char response[256];
                    snprintf(response, sizeof(response), "FILE_SERVER_RESPONSE:%d", mainPort);
                    
                    if (sendto(discoverySocket, response, strlen(response), 0,
                             (struct sockaddr*)&clientAddr, clientLen) > 0) {
                        std::cout << " 已响应发现请求" << std::endl;
                    }
                }
            }
        }
    }
}

void InteractiveTCPServer::handleClient(int clientSocket) {
    char clientIP[INET_ADDRSTRLEN];
    struct sockaddr_in clientAddr;
    socklen_t clientAddrLen = sizeof(clientAddr);
    
    if (getpeername(clientSocket, (struct sockaddr*)&clientAddr, &clientAddrLen) == 0) {
        inet_ntop(AF_INET, &clientAddr.sin_addr, clientIP, sizeof(clientIP));
    } else {
        strcpy(clientIP, "unknown");
    }

    try {
        char mode;
        ssize_t result = recv(clientSocket, &mode, 1, MSG_PEEK);
        
        if (result <= 0) {
            close(clientSocket);
            return;
        }

        ServerTransferHandlers transferHandler;

        if (mode == 'Q') {
            std::cout << " 断点查询来自: " << clientIP << std::endl;
            recv(clientSocket, &mode, 1, 0);
            transferHandler.handleResumeQuery(clientSocket);
        } else if (mode == 'R') {
            std::cout << " 重置传输来自: " << clientIP << std::endl;
            recv(clientSocket, &mode, 1, 0);
            transferHandler.handleResumeReset(clientSocket);
        } else if (mode == 'S') {
            std::cout << " 顺序传输来自: " << clientIP << std::endl;
            recv(clientSocket, &mode, 1, 0);
            transferHandler.handleSequentialTransfer(clientSocket);
        } else if (mode == 'M') {
            std::cout << " 多线程控制来自: " << clientIP << std::endl;
            recv(clientSocket, &mode, 1, 0);
            transferHandler.handleMultithreadControl(clientSocket);
        } else if (mode == 'D') {
            std::cout << " 文件夹传输来自: " << clientIP << std::endl;
            recv(clientSocket, &mode, 1, 0);
            transferHandler.handleDirectoryTransfer(clientSocket);
        } else {
            std::cout << " 数据块来自: " << clientIP << std::endl;
            transferHandler.handleChunkTransfer(clientSocket);
        }
    } catch (const std::exception& e) {
        std::cerr << "处理客户端错误: " << e.what() << std::endl;
        close(clientSocket);
    }
}