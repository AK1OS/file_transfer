#ifndef INTERACTIVE_TCP_SERVER_H
#define INTERACTIVE_TCP_SERVER_H

#include <atomic>

class InteractiveTCPServer {
private:
    int serverSocket;
    std::atomic<bool> running{false};
    std::atomic<bool> discoveryRunning{false};
    int discoverySocket;

public:
    InteractiveTCPServer(int port);
    ~InteractiveTCPServer();
    void start();

private:
    void handleClient(int clientSocket);
    void startDiscoveryService();
};

#endif