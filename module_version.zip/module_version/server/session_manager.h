#ifndef SESSION_MANAGER_H
#define SESSION_MANAGER_H

#include <map>
#include <memory>
#include <mutex>
#include <string>
#include <atomic>
#include <fstream>
#include <vector>
#include "../common/file_attributes.h"

struct ChunkInfo {
    int chunkIndex = -1;
    long startPos = 0;
    long long chunkSize = 0;
    bool received = false;
    bool writtenToFile = false;
    
    ChunkInfo() = default;
};

struct FileSession {
    std::string fileName;
    long long fileSize = 0;
    int totalChunks = 0;
    std::atomic<int> receivedChunks{0};
    std::atomic<int> writtenChunks{0};
    FileAttributes attrs;
    std::vector<ChunkInfo> chunks;
    std::mutex fileMutex;
    std::atomic<bool> completed{false};
    std::chrono::steady_clock::time_point startTime;
    int sessionId;
    std::unique_ptr<std::fstream> fileStream;
    
    FileSession(int id) : sessionId(id) {
        startTime = std::chrono::steady_clock::now();
    }
    
    FileSession(const FileSession&) = delete;
    FileSession& operator=(const FileSession&) = delete;
};

class SessionManager {
private:
    std::map<int, std::shared_ptr<FileSession>> sessions;
    std::mutex sessionsMutex;
    std::atomic<int> nextSessionId{1};

public:
    static SessionManager& getInstance() {
        static SessionManager instance;
        return instance;
    }

    std::shared_ptr<FileSession> getSession(int sessionId);
    int createSession();
    void removeSession(int sessionId);
    void monitorSession(int sessionId);
    void completeSession(std::shared_ptr<FileSession> session);
    std::string formatFileSize(long long bytes);
    
private:
    SessionManager() = default;
    SessionManager(const SessionManager&) = delete;
    SessionManager& operator=(const SessionManager&) = delete;
};

#endif