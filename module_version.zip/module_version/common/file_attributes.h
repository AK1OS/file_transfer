#ifndef FILE_ATTRIBUTES_H
#define FILE_ATTRIBUTES_H

#include <sys/stat.h>
#include <ctime>

struct FileAttributes {
    mode_t permissions;
    struct timespec access_time;
    struct timespec modify_time;
    uid_t uid;
    gid_t gid;
    
    FileAttributes() : permissions(0644), uid(0), gid(0) {
        access_time.tv_sec = 0;
        access_time.tv_nsec = 0;
        modify_time.tv_sec = 0;
        modify_time.tv_nsec = 0;
    }
};

#endif