#ifndef SERVER_NETWORK_UTILS_H
#define SERVER_NETWORK_UTILS_H

#include "../common/file_attributes.h"
#include <string>

class ServerNetworkUtils {
public:
    static bool setFileAttributes(const std::string& filename, const FileAttributes& attrs);
    static std::string formatFileSize(long long bytes);
    static bool ensureDirectoryExists(const std::string& path);
    static long long receiveFileData(int socket, std::ostream& file, long long expectedSize);
    static long long sendFileData(int socket, std::istream& file, long long sizeToSend);
    static bool receiveExact(int socket, void* buffer, size_t size);
    static bool sendExact(int socket, const void* buffer, size_t size);
    static std::string getLocalIP();
    static bool isPortAvailable(int port);
    static bool setSocketNonBlocking(int socket);
    static bool setSocketBlocking(int socket);
};

#endif