#include "network_utils.h"
#include "../common/constants.h"
#include <iostream>
#include <fstream>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/stat.h>
#include <ctime>
#include <sys/time.h>
#include <ifaddrs.h>
#include <cstring>
#include <iomanip>
#include <fcntl.h>
#include <dirent.h>
#include <vector>

bool ServerNetworkUtils::setFileAttributes(const std::string& filename, const FileAttributes& attrs) {
    bool success = true;
    
    if (chmod(filename.c_str(), attrs.permissions) != 0) {
        std::cerr << "  设置文件权限失败: " << strerror(errno) << std::endl;
        success = false;
    }
    
    if (chown(filename.c_str(), attrs.uid, attrs.gid) != 0) {
        if (errno != EPERM) {
            std::cerr << "  设置文件所有者失败: " << strerror(errno) << std::endl;
        }
    }
    
    struct timespec times[2];
    times[0] = attrs.access_time;
    times[1] = attrs.modify_time;
    
    #ifdef __APPLE__
        struct timeval timevals[2];
        timevals[0].tv_sec = times[0].tv_sec;
        timevals[0].tv_usec = times[0].tv_nsec / 1000;
        timevals[1].tv_sec = times[1].tv_sec;
        timevals[1].tv_usec = times[1].tv_nsec / 1000;
        
        if (utimes(filename.c_str(), timevals) != 0) {
            std::cerr << "  设置文件时间戳失败: " << strerror(errno) << std::endl;
            success = false;
        }
    #else
        if (utimensat(AT_FDCWD, filename.c_str(), times, 0) != 0) {
            std::cerr << "  设置文件时间戳失败: " << strerror(errno) << std::endl;
            success = false;
        }
    #endif
    
    return success;
}

std::string ServerNetworkUtils::formatFileSize(long long bytes) {
    const char* sizes[] = {"B", "KB", "MB", "GB"};
    int order = 0;
    double size = bytes;
    while (size >= 1024 && order < 3) {
        order++;
        size /= 1024;
    }
    
    std::string result = std::to_string(size);
    size_t dotPos = result.find('.');
    if (dotPos != std::string::npos) {
        if (dotPos + 3 < result.length()) {
            result = result.substr(0, dotPos + 3);
        }
    }
    return result + " " + sizes[order];
}

bool ServerNetworkUtils::ensureDirectoryExists(const std::string& path) {
    size_t pos = 0;
    std::string dir;
    
    if (path[0] == '/') {
        dir = "/";
        pos = 1;
    }
    
    while (pos < path.length()) {
        size_t next = path.find('/', pos);
        if (next == std::string::npos) {
            break;
        }
        
        dir += path.substr(pos, next - pos + 1);
        pos = next + 1;
        
        if (mkdir(dir.c_str(), 0755) != 0 && errno != EEXIST) {
            return false;
        }
    }
    
    return true;
}

long long ServerNetworkUtils::receiveFileData(int socket, std::ostream& file, long long expectedSize) {
    std::vector<char> buffer(BUFFER_SIZE);
    long long received = 0;
    
    while (received < expectedSize) {
        long long remaining = expectedSize - received;
        size_t toReceive = std::min(remaining, static_cast<long long>(buffer.size()));
        
        int bytesRead = recv(socket, buffer.data(), toReceive, 0);
        if (bytesRead <= 0) {
            break;
        }
        
        file.write(buffer.data(), bytesRead);
        if (!file.good()) {
            throw std::runtime_error("文件写入失败");
        }
        
        received += bytesRead;
    }
    
    return received;
}

long long ServerNetworkUtils::sendFileData(int socket, std::istream& file, long long sizeToSend) {
    std::vector<char> buffer(BUFFER_SIZE);
    long long sent = 0;
    
    while (sent < sizeToSend) {
        long long remaining = sizeToSend - sent;
        size_t toRead = std::min(remaining, static_cast<long long>(buffer.size()));
        
        file.read(buffer.data(), toRead);
        int bytesRead = file.gcount();
        
        if (bytesRead > 0) {
            int bytesSent = 0;
            while (bytesSent < bytesRead) {
                int result = send(socket, buffer.data() + bytesSent, bytesRead - bytesSent, 0);
                if (result <= 0) {
                    return sent;
                }
                bytesSent += result;
            }
            sent += bytesRead;
        } else {
            break;
        }
    }
    
    return sent;
}

bool ServerNetworkUtils::receiveExact(int socket, void* buffer, size_t size) {
    char* data = static_cast<char*>(buffer);
    size_t received = 0;
    
    while (received < size) {
        int result = recv(socket, data + received, size - received, MSG_WAITALL);
        if (result <= 0) {
            return false;
        }
        received += result;
    }
    
    return true;
}

bool ServerNetworkUtils::sendExact(int socket, const void* buffer, size_t size) {
    const char* data = static_cast<const char*>(buffer);
    size_t sent = 0;
    
    while (sent < size) {
        int result = send(socket, data + sent, size - sent, 0);
        if (result <= 0) {
            return false;
        }
        sent += result;
    }
    
    return true;
}

std::string ServerNetworkUtils::getLocalIP() {
    struct ifaddrs* ifaddr;
    std::string localIP = "127.0.0.1";
    
    if (getifaddrs(&ifaddr) == 0) {
        for (struct ifaddrs* ifa = ifaddr; ifa != nullptr; ifa = ifa->ifa_next) {
            if (ifa->ifa_addr == nullptr) continue;
            if (ifa->ifa_addr->sa_family != AF_INET) continue;
            if (strcmp(ifa->ifa_name, "lo") == 0) continue;
            
            struct sockaddr_in* addr = (struct sockaddr_in*)ifa->ifa_addr;
            char ip[INET_ADDRSTRLEN];
            inet_ntop(AF_INET, &addr->sin_addr, ip, sizeof(ip));
            
            if (strncmp(ip, "127.", 4) != 0) {
                localIP = ip;
                break;
            }
        }
        freeifaddrs(ifaddr);
    }
    
    return localIP;
}

bool ServerNetworkUtils::isPortAvailable(int port) {
    int testSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (testSocket < 0) {
        return false;
    }
    
    int opt = 1;
    setsockopt(testSocket, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
    
    struct sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port = htons(port);
    
    bool available = (bind(testSocket, (struct sockaddr*)&addr, sizeof(addr)) == 0);
    close(testSocket);
    
    return available;
}

bool ServerNetworkUtils::setSocketNonBlocking(int socket) {
    int flags = fcntl(socket, F_GETFL, 0);
    if (flags == -1) {
        return false;
    }
    return fcntl(socket, F_SETFL, flags | O_NONBLOCK) != -1;
}

bool ServerNetworkUtils::setSocketBlocking(int socket) {
    int flags = fcntl(socket, F_GETFL, 0);
    if (flags == -1) {
        return false;
    }
    return fcntl(socket, F_SETFL, flags & ~O_NONBLOCK) != -1;
}