#ifndef SERVER_TRANSFER_HANDLERS_H
#define SERVER_TRANSFER_HANDLERS_H

#include <string>
#include <map>
#include <mutex>
#include <memory>
#include "../common/file_attributes.h"
#include "session_manager.h"  

class ServerTransferHandlers {
private:
    std::map<std::string, long long> resumePoints;
    std::mutex resumeMutex;

public:
    void handleResumeQuery(int clientSocket);
    void handleResumeReset(int clientSocket);
    void handleSequentialTransfer(int clientSocket);
    void handleMultithreadControl(int clientSocket);
    void handleChunkTransfer(int clientSocket);
    void handleDirectoryTransfer(int clientSocket);

private:
    std::string formatFileSize(long long bytes);
    bool handleDirectoryItem(int clientSocket, const std::string& basePath);
    bool handleDirectoryFile(int clientSocket, const std::string& basePath);
};

#endif