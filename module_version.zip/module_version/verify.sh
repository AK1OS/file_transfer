#!/bin/bash
# 快速文件/文件夹校验脚本

if [[ $# -ne 2 ]]; then
    echo "用法: $0 <路径1> <路径2>"
    exit 1
fi

PATH1="$1"
PATH2="$2"

# 检查路径是否存在
if [[ ! -e "$PATH1" || ! -e "$PATH2" ]]; then
    echo "错误: 路径不存在"
    exit 1
fi

echo "快速校验: $PATH1 vs $PATH2"
echo "=========================="

if [[ -f "$PATH1" && -f "$PATH2" ]]; then
    # 文件比较
    if cmp -s "$PATH1" "$PATH2"; then
        echo "✅ 文件内容一致"
    else
        echo "❌ 文件内容不同"
        exit 1
    fi
elif [[ -d "$PATH1" && -d "$PATH2" ]]; then
    # 文件夹比较
    if diff -qr "$PATH1" "$PATH2" > /dev/null; then
        echo "✅ 文件夹内容一致"
    else
        echo "❌ 文件夹内容不同"
        diff -qr "$PATH1" "$PATH2"
        exit 1
    fi
else
    echo "错误: 路径类型不匹配"
    exit 1
fi