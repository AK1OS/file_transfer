#ifndef TRANSFER_STATS_H
#define TRANSFER_STATS_H

#include <atomic>
#include <chrono>
#include <mutex>

struct TransferStats {
    std::atomic<long> totalSent{0};
    std::atomic<int> completedChunks{0};
    long fileSize{0};
    std::chrono::steady_clock::time_point startTime;
    std::mutex consoleMutex;
};

#endif